//
//  WeatherService.swift
//  WeatherApp
//
//  Created by Essam Mahmoud fathy on 9/25/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import Foundation

protocol WeaterServiceDelegate {
    func setWeather(weather: Weather)
}
class WeatherService {
     static var delegate : WeaterServiceDelegate?
    static func GetWeather(city : String){
        let path = "http://api.openweathermap.org/find?q=\(city)&appid=fe6bc4c72314b3709c3d8348a8906618"
        let Url = URL(string: path)
        let request = URLSession.shared.dataTask(with: Url!) { (data, response, error) in
            if let httpresponse = response as? HTTPURLResponse {
                print(httpresponse.statusCode)
            }
            do{
                if error == nil {
                    if let unrappedData = data {
                        let json = try JSON(data: unrappedData )
                        let temp = json["main"]["temp"].double
                        let name = json["name"].string
                        let desc = json["weather"][0]["description"].string
                        let icon = json["weather"][0]["icon"].string
                        let hummidity  = json["main"]["humidity"].double
                        let wind = json["wind"]["speed"].double
                        let MyWeather = Weather(cityName: name!, temp: temp!, description: desc!, icon: icon!, humidity : hummidity!,windspeed : wind!)
                        if delegate != nil {
                            DispatchQueue.main.async {
                                self.delegate?.setWeather(weather: MyWeather)
                            }
                           
                        }
                        
                    }
                }
            }catch{
                print("Error")
            }
        }.resume()
        //let weatherMe = Weather(cityName: city, temp: 25.5, description: "NiceDay")
        //delegate?.setWeather(weather: weatherMe)
    }
}
