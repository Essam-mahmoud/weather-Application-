//
//  MyCustomButton.swift
//  WeatherApp
//
//  Created by Essam Mahmoud fathy on 9/25/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit
@IBDesignable
class MyCustomButton: UIButton {

    @IBInspectable var BorderWidth : CGFloat = 0 {
        didSet{
            self.layer.borderWidth = BorderWidth
        }
    }
    @IBInspectable var BorderColor : UIColor = UIColor.clear {
        didSet{
            self.layer.borderColor = BorderColor.cgColor
        }
    }
    @IBInspectable var Cornor : CGFloat = 0 {
        didSet{
            self.layer.cornerRadius = Cornor
        }
    }
}
