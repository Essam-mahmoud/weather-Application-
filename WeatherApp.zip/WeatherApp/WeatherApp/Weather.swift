//
//  Weather.swift
//  WeatherApp
//
//  Created by Essam Mahmoud fathy on 9/25/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import Foundation

struct Weather {
    let cityName: String
    let temp: Double
    let description: String
    let icon : String
    let humidity : Double
    let windspeed : Double
    init(cityName : String , temp: Double, description: String, icon : String, humidity : Double, windspeed : Double) {
        self.cityName = cityName
        self.temp = temp
        self.description = description
        self.icon = icon
        self.humidity = humidity
        self.windspeed = windspeed
    }
}
