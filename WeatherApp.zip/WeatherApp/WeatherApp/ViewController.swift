//
//  ViewController.swift
//  WeatherApp
//
//  Created by Essam Mahmoud fathy on 9/25/18.
//  Copyright © 2018 Essam Mahmoud fathy. All rights reserved.
//

import UIKit

class ViewController: UIViewController ,WeaterServiceDelegate {
    
    
    func setWeather(weather: Weather) {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 1
        let f = formatter.string(from: NSNumber(value: weather.temp - 273))
        TembLable.text = "\(f!) C"
        ImageWeather.image = UIImage(named: "\(weather.icon)")
        HummidityLable.text = String(weather.humidity)
        WindLable.text = String(weather.windspeed)
        
    }
    
    
    @IBOutlet weak var CityTXT: UITextField!
    @IBOutlet weak var ImageWeather: UIImageView!
    @IBOutlet weak var WindLable: UILabel!
    @IBOutlet weak var HummidityLable: UILabel!
    @IBOutlet weak var TembLable: UILabel!
    var weaterService = WeatherService()
    override func viewDidLoad() {
        super.viewDidLoad()
        ImageWeather.layer.cornerRadius = 20
        ImageWeather.clipsToBounds = true
        WeatherService.delegate = self
    }

    @IBAction func OKAction(_ sender: MyCustomButton) {
        createAlert()
    }
    @objc func createAlert(){
        let Alert = UIAlertController(title: "City", message: "Please Enter your city", preferredStyle: .alert)
        let AlertAc = UIAlertAction(title: "Ok", style: .default) { (action : UIAlertAction) in
            let textF = Alert.textFields![0]
            let city = textF.text!
            WeatherService.GetWeather(city: city)
            Alert.addTextField(configurationHandler: { (textfiled : UITextField) in
                textfiled.placeholder = "City Name"
            })
        }
        let AlertAc2 = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        Alert.addAction(AlertAc)
        Alert.addAction(AlertAc2)
        self.present(Alert, animated: true, completion: nil)
    }


}

